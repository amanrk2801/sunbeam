﻿

using System;

namespace Demo
{
    public class Program
    {
        static void Main(string[] args)
        {
            int i = 100;
            Console.WriteLine("Hello C#");
            Console.ReadLine();
        
        }
    }
}
