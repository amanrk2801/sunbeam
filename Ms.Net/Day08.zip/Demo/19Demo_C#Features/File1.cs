﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19Demo_C_Features
{
    //Written by Mahesh
    public partial class Maths
    {
        public int Add  (int x, int y)
        {
            return x + y;
        }
    }
}
