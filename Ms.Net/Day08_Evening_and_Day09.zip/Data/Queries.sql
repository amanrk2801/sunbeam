 create table Emp ( Address varchar(50),Name varchar(50),No int ); create table Department ( DNo int,DName varchar(50) );
