﻿namespace _04DemoOOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    //public sealed class A
    //{

    //}

    //public class B: A
    //{
        
    //}
}
