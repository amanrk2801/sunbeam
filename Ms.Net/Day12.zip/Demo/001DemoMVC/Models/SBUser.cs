﻿namespace _001DemoMVC.Models
{
    public class SBUser
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
