﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19Demo_C_Features
{
    //Written by Raj
    public partial class Maths
    {
        public int Sub(int x, int y)
        {
            return x - y;
        }
    }

    //Written by Raj
    public partial class Test
    {
        partial void Validate(string value)
        {
            //Logic
            Console.WriteLine("Raj's validation method");
        }
    }
}
