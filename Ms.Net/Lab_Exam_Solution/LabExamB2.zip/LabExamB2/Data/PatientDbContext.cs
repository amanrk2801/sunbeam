﻿using LabExamB2.Models;
using Microsoft.EntityFrameworkCore;

namespace LabExamB2.Data
{
    public class PatientDbContext : DbContext
    {
        public PatientDbContext(DbContextOptions<PatientDbContext> options) : base(options) { }

            public DbSet<Patient> Patients { get; set; }
        }
    }

