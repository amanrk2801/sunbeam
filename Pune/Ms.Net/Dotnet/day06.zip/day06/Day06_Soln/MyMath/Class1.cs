﻿namespace MyMath
{
    public class MyMath
    {
        public readonly double PI = 3.14;
        public int Add(int x, int y)
        {
            return x + y;
        }
        public int Subtract(int x, int y)
        {
            return x - y;
        }
        private int Multiply(int x, int y)
        {
            return x * y;
        }
    }
}
