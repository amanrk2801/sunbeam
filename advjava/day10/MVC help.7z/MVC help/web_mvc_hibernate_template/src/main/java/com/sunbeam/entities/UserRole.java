package com.sunbeam.entities;

public enum UserRole {
	ADMIN, VOTER
}
