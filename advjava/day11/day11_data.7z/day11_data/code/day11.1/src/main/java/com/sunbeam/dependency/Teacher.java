package com.sunbeam.dependency;

public interface Teacher {
	void teach();
}
