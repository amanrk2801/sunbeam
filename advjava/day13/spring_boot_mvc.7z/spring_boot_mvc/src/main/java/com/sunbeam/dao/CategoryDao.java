package com.sunbeam.dao;

import java.util.List;

import com.sunbeam.entities.Category;

public interface CategoryDao {
	List<Category> getAllCategories();
}
