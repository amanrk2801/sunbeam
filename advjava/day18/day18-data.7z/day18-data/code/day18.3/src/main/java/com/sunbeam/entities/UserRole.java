package com.sunbeam.entities;

public enum UserRole {
	ROLE_ADMIN, ROLE_CUSTOMER, ROLE_DELIVERY_PERSON
}
