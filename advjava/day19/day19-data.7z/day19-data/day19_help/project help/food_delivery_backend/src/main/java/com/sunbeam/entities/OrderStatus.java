package com.sunbeam.entities;

public enum OrderStatus {
	NEW, PROCESSING, DELIVERED, CANCELLED
}
