package com.app.entities;

public enum UserRole {
	ROLE_CUSTOMER, ROLE_ADMIN, ROLE_USER
}
