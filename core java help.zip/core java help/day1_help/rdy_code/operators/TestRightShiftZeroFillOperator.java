package operators;

public class TestRightShiftZeroFillOperator {

	public static void main(String[] args) {
		int a =20;
		System.out.println(a>>>2);//5
		 a =-1;
		System.out.println(a>>>20);//4095
		
		

	}

}
