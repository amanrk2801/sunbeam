package com.sunbeam;

import java.util.*;

//Movie class
class Movie {
    String title;
    String director;
    double rating;
    Movie prev ;
    Movie next;

    Movie(String title, String director, double rating) {
        this.title = title;
        this.director = director;
        this.rating = rating;
        this.prev = this.next = null;
    }
}

public class MovieDCLL {
    Movie head = null;

    //1. Add Movie at End
    public void addMovie(String title, String director, double rating) {
        Movie nn = new Movie(title, director, rating);
        if (head == null) {
            head = nn;
            head.next = head.prev = head;
        } else {
            Movie temp = head;
            while (temp.next != head)
                temp = temp.next;
            temp.next = nn;
            nn.prev = temp;
            nn.next = head;
            head.prev = nn;
        }
    }

    //2. Delete Movie by Title
    public void deleteMovie(String title) {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Movie temp = head;
        do {
            if (temp.title.equalsIgnoreCase(title)) {
                if (temp.next == temp) {
                    head = null;
                } else {
                    temp.prev.next = temp.next;
                    temp.next.prev = temp.prev;
                    if (temp == head)
                        head = temp.next;
                }
                System.out.println("Movie deleted: " + title);
                return;
            }
            temp = temp.next;
        } while (temp != head);

        System.out.println("Movie not found.");
    }

    //3. Display All Movies
    public void displayAll() {
        if (head == null) {
            System.out.println("No movies to display.");
            return;
        }

        Movie temp = head;
        System.out.println("Movies List:");
        do {
            System.out.println("Title: " + temp.title + ", Director: " + temp.director + ", Rating: " + temp.rating);
            temp = temp.next;
        } while (temp != head);
    }

    //4. Display Movies by Director
    public void displayByDirector(String director) {
        if (head == null) {
            System.out.println("No movies in list.");
            return;
        }

        boolean varible = false;
        Movie temp = head;
        System.out.println("Movies by Director: " + director);
        do {
            if (temp.director.equalsIgnoreCase(director)) {
                System.out.println("Title: " + temp.title + ", Rating: " + temp.rating);
                varible = true;
            }
            temp = temp.next;
        } while (temp != head);

        if (!varible)
            System.out.println("No movies found by this director.");
    }

    //5. Top 3 Movies by Rating
    public void topmovies() {
        if (head == null) {
            System.out.println("No movies to rank.");
            return;
        }

        List<Movie> list = new ArrayList<>();
        Movie temp = head;
        do {
            list.add(temp);
            temp = temp.next;
        } while (temp != head);

        list.sort((a, b) -> Double.compare(b.rating, a.rating));

        System.out.println("Top 3 Movies:");
        for (int i = 0; i < Math.min(3, list.size()); i++) {
            Movie m = list.get(i);
            System.out.println((i + 1) + ". " + m.title + " - " + m.director + " - " + m.rating);
        }
    }

    //6. Count Movies by Director
    public void countByDirector() {
        if (head == null) {
            System.out.println("No movies in the list.");
            return;
        }

        HashMap<String, Integer> countMap = new HashMap<>();
        Movie temp = head;
        do {
            countMap.put(temp.director, countMap.getOrDefault(temp.director, 0) + 1);
            temp = temp.next;
        } while (temp != head);

        System.out.println("Movies Count by Director:");
        for (Map.Entry<String, Integer> entry : countMap.entrySet()) {
            System.out.println("Director: " + entry.getKey() + ", Movies: " + entry.getValue());
        }
    }

    // Main - Menudriven program
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MovieDCLL list = new MovieDCLL();
        int choice;

        do {
            System.out.println("\n--- Movie Menu ---");
            System.out.println("1. Add Movie");
            System.out.println("2. Delete Movie by Title");
            System.out.println("3. Display All Movies");
            System.out.println("4. Display Movies by Director");
            System.out.println("5. Top 3 Rated Movies");
            System.out.println("6. Count Movies by Each Director");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Director: ");
                    String director = sc.nextLine();
                    System.out.print("Enter Rating: ");
                    double rating = sc.nextDouble();
                    list.addMovie(title, director, rating);
                    break;
                case 2:
                    System.out.print("Enter Title to Delete: ");
                    String dTitle = sc.nextLine();
                    list.deleteMovie(dTitle);
                    break;
                case 3:
                    list.displayAll();
                    break;
                case 4:
                    System.out.print("Enter Director: ");
                    String dir = sc.nextLine();
                    list.displayByDirector(dir);
                    break;
                case 5:
                    list.topmovies();
                    break;
                case 6:
                    list.countByDirector();
                    break;
                case 7:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 7);

        sc.close();
    }
}
