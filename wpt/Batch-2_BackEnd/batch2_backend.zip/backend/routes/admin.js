const express = require('express')
const cryptoJs = require('crypto-js')
const jwt = require('jsonwebtoken')
const result = require('../utils/result')
const config = require('../utils/config')
const pool = require('../db')
const db = require('../db')
const router = express.Router()

router.post('/register', (req, res) => {
    const { name, email, password, phone } = req.body
    const encryptedPassword = String(cryptoJs.SHA256(password))
    const sql = `INSERT INTO admin(name,email,password,phone) VALUES(?,?,?,?)`
    db.pool.query(
      sql,
      [name,email,encryptedPassword,phone],
      (error, data) => {
        res.send(result.createResult(error, data))
      }
    )
  })


router.post('/login', (req, res) => {
    const { email, password } = req.body
    const encryptedPassword = String(cryptoJs.SHA256(password))
    const sql = `SELECT * FROM admin WHERE email = ? AND password = ?`
    db.pool.query(sql, [email, encryptedPassword], (error, data) => {
      if (data) {
        if (data.length != 0) {
          const payload = {
            userId: data[0].id,
          }
          const token = jwt.sign(payload, config.secret)
          const body = {
            token: token,
            name: data[0].Name
            
          }
          res.send(result.createSuccessResult(body))
        } else res.send(result.createErrorResult('Invalid email or password'))
      } else res.send(result.createErrorResult(error))
    })
  })
module.exports = router