
const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const pool = require('../db/db'); 
const app = express();
const router = express.Router()
const result = require('../utils/result')

// Setup multer storage
const upload = multer({ dest: 'images/' });

// Add car with image
router.post('/addcar', upload.single('image'), (request, response) => {
  const newFileName = request.file.filename + '.jpg';
  fs.rename(request.file.path, `${request.file.destination}${newFileName}`, (err) => {
    if (err) {
      return response.status(500).send('Error saving the file');
    }

    const { name, model, price, carColor, fuel_type } = request.body;
    const statement = `
      INSERT INTO car(name, model, price, carColor, fuel_type, image)
      VALUES(?, ?, ?, ?, ?, ?)`;

    pool.query(statement, [name, model, price, carColor, fuel_type, newFileName], (error, data) => {
      if (error) {
        return response.status(500).send('Error inserting data');
      }
      response.send(data);
    });
  });
});

// Get all cars
router.get('/getcars', (request, response) => {
  const statement = `SELECT * FROM car`;
  pool.query(statement, (error, data) => {
    if (error) {
      return response.status(500).send('Error fetching cars');
    }
    response.send(data);
  });
});

 router.put('/:id', (request, response)=> {

     const id = request.params.id
  const {price,carColor} = request.body
  const statement =  `update car set price=? ,carColor=? where id=?`
  pool.query(statement, [price, carColor, id], (error, data) => {
     response.send(result.createResult(error, data))
 })
 })

 router.delete('/:id', (request, response) => {
     const id = request.params.id
     const statement = `
     DELETE FROM car WHERE id = ?`
     pool.query(statement, [id], (error, data) => {
         response.send(result.createResult(error, data))
     })
 })


module.exports = router