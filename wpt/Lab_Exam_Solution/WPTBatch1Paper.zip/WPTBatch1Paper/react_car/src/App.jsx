import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AddCar from "./component/AddCar";
import DisplayCars from "./component/DisplayCars";
import EditCar from './component/EditCar';

function App() {
 
  return (
    <Router>
      <Routes>
        
        <Route path="/" element={<AddCar />} />
        <Route path="/displaycar" element={<DisplayCars />} />
        <Route path="/editcar" element={<EditCar />} /> 


        <Route></Route>
      </Routes>
    </Router>
  )
}

export default App
