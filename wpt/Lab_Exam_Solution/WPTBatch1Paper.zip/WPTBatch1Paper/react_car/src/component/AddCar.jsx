
import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddCar = () => {
  const [car, setCar] = useState({
    name: "",
    model: "",
    price: "",
    carColor: "",
    fuel_type: "",
    image: null, // Changed to store the file instead of a string
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCar({ ...car, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setCar({ ...car, image: e.target.files[0] }); // Storing the file in the state
  };

  const handleAddCar = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("name", car.name);
    formData.append("model", car.model);
    formData.append("price", car.price);
    formData.append("carColor", car.carColor);
    formData.append("fuel_type", car.fuel_type);
    formData.append("image", car.image); // Append the image file

    try {
      await axios.post("http://localhost:4000/car/addcar", formData, {
        headers: {
          "Content-Type": "multipart/form-data", // Important for file upload
        },
      });
      navigate("/displaycar");
    } catch (error) {
      console.error("Add car failed:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h2>Add Car</h2>
      <form onSubmit={handleAddCar}>
        {["name", "model", "price", "carColor", "fuel_type"].map((field) => (
          <div className="mb-3" key={field}>
            <input
              type="text"
              name={field}
              placeholder={field}
              value={car[field]}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
        ))}

        <div className="mb-3">
          <input
            type="file"
            name="image"
            onChange={handleFileChange} // Handle the file change
            className="form-control"
            required
          />
        </div>

        <button className="btn btn-success">Add Car</button>
      </form>
    </div>
  );
};

export default AddCar;
