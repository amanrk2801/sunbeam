
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate,useLocation } from 'react-router-dom';

const CarList = () => {
  const [cars, setCars] = useState([]);
  const navigate = useNavigate();
  const location=useLocation();

  const fetchCars = async () => {
    try {
      const res = await axios.get('http://localhost:4000/car/getcars');
      setCars(res.data);
    } catch (error) {
      console.error('Error fetching cars:', error);
    }
  };

  const handleDelete = async (id) => {
      
        await axios.delete(`http://localhost:4000/car/${id}`);
        fetchCars(); 
      
  };

  const handleEdit = (id) => {

    navigate(`/editcar`,{state:{id}})
  };

  useEffect(() => {
    fetchCars();
  }, []);

  return (
    <div className="p-6 grid gap-4 grid-cols-2">
      {cars.map((car, index) => (
        <div key={index} className="border rounded-xl shadow p-4">
          <img
            src={`http://localhost:4000/images/${car.image}`}
            alt={car.name}
            className="w-full h-48 object-cover mb-2 rounded"
          />
          <h2 className="text-xl font-bold">{car.name}</h2>
          <p>Model: {car.model}</p>
          <p>Price: ₹{car.price}</p>
          <p>Color: {car.carColor}</p>
          <p>Fuel Type: {car.fuel_type}</p>
          <div className="mt-3 flex gap-2">
            <button
              onClick={() => handleEdit(car.id)}
              type="button" className="btn btn-info">
            
              Edit
            </button>
            <button
              onClick={() => handleDelete(car.id)}
             type="button" className="btn btn-danger me-md-2 "
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CarList;
