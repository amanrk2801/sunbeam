
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Toast } from 'bootstrap';

const EditCar = () => {
    const [carId, setCarId] = useState('');
    const [price, setPrice] = useState('');
    const [carColor, setCarColor] = useState('');

    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() => {
        const { id } = location.state;
        if (id) {
            setCarId(id);

            axios.get(`http://localhost:4000/car/${id}`)
                .then((res) => {
                    console.log(res)
                    setPrice(res.data.price);
                    setCarColor(res.data.carColor);
                    navigate('/displaycar');
                })
                .catch((err) => {
                    console.error('Error loading car data', err);

                });
        } else {

        Toast.warn("error while editing");
        ;
        }
    }, []);

    const update = () => {
        if (!price) {
            toast.error('Please enter price');
            return;
        }
        if (!carColor) {
            toast.error('Please enter car color');
            return;
        }

        const body = {
            price,
            carColor,
        };

        axios.put(`http://localhost:4000/car/${carId}`, body)
            .then((response) => {
                toast.success('Car updated successfully');
                navigate('/displaycar');
            })
            .catch((error) => {
                console.error('Update error:', error);
                toast.error('Failed to update car');
            });
    };

    return (
        <div className="container mt-5">
            <h2 className="text-center mb-4">Edit Car</h2>
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <div className="card p-4 shadow">
                        <div className="mb-3">
                            <label htmlFor="price" className="form-label">Price:</label>
                            <input
                                id="price"
                                type="number"
                                className="form-control"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                                placeholder="Enter price"
                            />
                        </div>

                        <div className="mb-3">
                            <label htmlFor="carColor" className="form-label">Car Color:</label>
                            <input
                                id="carColor"
                                type="text"
                                className="form-control"
                                value={carColor}
                                onChange={(e) => setCarColor(e.target.value)}
                                placeholder="Enter car color"
                            />
                        </div>

                        <div className="d-grid">
                            <button className="btn btn-primary" onClick={update}>
                                Update Car
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    );
};

export default EditCar;


