const express = require('express');
const cors = require('cors');

const userRoutes = require('./routes/admin')


const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/admin', userRoutes);


app.listen(4000, '0.0.0.0', () => {
    console.log('server started on port 4000')
})