module.exports = {
    secret: "uaibfjkendu2982y347832y4bebjsjasb"
}