import React, { createContext, useState } from 'react'

import { BrowserRouter as Router,Routes, Route } from "react-router-dom";
import Login from './components/Login'
import { ToastContainer } from 'react-toastify'
// import './App.css';
import Register from './components/Register';
import Home from './components/Home';

export const AuthContext = createContext()

function App () {

  const [admin, setAdmin] = useState(null)
  
  return (
    <div>
      <AuthContext.Provider value={{ admin, setAdmin }}> 
    
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route
            path='/'
            element={<Register />}
          />
           <Route
            path='/home'
            element={<Home/>}
          />
      </Routes>
      
     </AuthContext.Provider> 
      <ToastContainer />
    
    </div>
  );
};

export default App