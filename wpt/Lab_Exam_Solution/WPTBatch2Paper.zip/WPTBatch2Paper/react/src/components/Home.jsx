import React, { useContext } from 'react'
import { AuthContext } from '../App'

function Home() {
    const {admin} = useContext(AuthContext)
  return (
    <div>
      <h1 className='page-header'>Home</h1>
      <div>
        Welcome {admin.name}
      </div>
    </div>
  )
}

export default Home
