import React, { useContext, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../App";

const Login = () => {
  const{setAdmin}=useContext(AuthContext)
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  

  const handleLogin = async (e) => {
    debugger
    
    e.preventDefault()
    try {
      const res = await axios.post("http://localhost:4000/admin/login", { email, password });
      console.log(res.data.data.name)
      if (res.data.status === "success") {
        // persist the login information like token, username etc
               const {name, token} = res.data.data  

        //persist the info in session storage
        sessionStorage.setItem('name', name)
        sessionStorage.setItem('token', token)
        
        debugger
         setAdmin ({
           name:res.data.data.name
         })
        navigate("/home")
      } else {
        alert("Invalid email or password");
      }
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div className="mb-3">
          <input type="email" placeholder="Email" value={email}
            onChange={(e) => setEmail(e.target.value)} className="form-control" required />
        </div>
        <div className="mb-3">
          <input type="password" placeholder="Password" value={password}
            onChange={(e) => setPassword(e.target.value)} className="form-control" required />
        </div>
        <button className="btn btn-primary">Login</button>
      </form>
    </div>
  );
};

export default Login;
