export const config = {
    serverUrl: 'http://localhost:4000',
  }
  